﻿using System;

namespace Shapes
{
    public abstract class Shape
    {
        abstract public double Area { get; }
    }
}
