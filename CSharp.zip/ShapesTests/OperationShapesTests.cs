﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using Shapes;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Shapes.Tests
{
    [TestClass()]
    public class OperationShapesTests
    {
        private const float areaExpected = 54.5F;
        [TestMethod()]
        public void BuildTest()
        {
            Shape squareOne = new Square(5, 4);
            Shape squareTwo = new Square(3, 4);
            Shape triangleOne = new Triangle(5, 9);

            List<Shape> listOfShapes = new List<Shape> { squareOne, squareTwo, triangleOne };

            var sumations = listOfShapes.Sum(shapes => shapes.Area);


            Assert.AreEqual(areaExpected, sumations);

        }
    }
}